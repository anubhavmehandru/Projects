
<? session_start();
include 'table_view.class.php';
include '../include/conn.php';
									$a=$_SESSION['a'];
									grid($a);
									
									
									?>