                                     <?php
                                     if(isset($_GET['page']))
                                     {
                                            if($_GET['page']=='bday')
                                            {
                                                echo '<div style="display:none">';
                                            }   
                                                
                                      }     
                                     ?>
                                      <?php  if(isset($_GET['page']))
                                     {
                                            if($_GET['page']=='bday')
                                            {
                                                echo '</div>';
                                            }   
                                                
                                      } 
                                      ?>
                                    </div>
                                </div>
                                
                                <div class="navbar navbar-default navbar-fixed-bottom" style="min-height:25px;overflow:hidden;">
                                   <div class="container">
                                        <p class="navbar-text" style="margin:0px;margin-top:3px;">Developed By 3CM</p>
                                        <p class="navbar-text pull-right" style="margin:0px;margin-top:3px;">Proprietor: Devinder Mehandru </p>
										</a>
                                       <!-- <a href="..//www.3cmgroup.in" target="_blank" class=" pull-right navbar-btn btn-danger btn">3CM GROUP</a>-->
                                    </div>
                                </div>
        
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>
