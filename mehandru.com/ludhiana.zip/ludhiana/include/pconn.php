<?php

$pcon=mysqli_connect("sg2nlmysql59plsk.secureserver.net:3306","3cm-spares","Mehandru@#123","service-spares");
					 
if(!$pcon)
{
    echo mysqli_error($pcon);
}


?>