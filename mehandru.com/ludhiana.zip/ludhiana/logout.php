<?php
        unset($_SESSION['ulog']);
        echo '<script>window.location="login.php";</script>';
    ?>