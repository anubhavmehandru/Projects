<?php

$con=mysqli_connect("sg2nlmysql59plsk.secureserver.net:3306","mehandru","Mehandru@#123","3cm_service");
					 
    if(!$con)
    {
        echo mysqli_error($con);
    }
   
?>
